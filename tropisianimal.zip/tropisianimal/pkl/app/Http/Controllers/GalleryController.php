<?php

namespace App\Http\Controllers;
use App\Gallery;
use File;
use Illuminate\Http\Request;

class GalleryController extends Controller
{
    //
    public function index()
    {
        return view('admin.gallery.index', [
            'gallery' => Gallery::all()
        ]);
    }

    public function create()
    {
        return view('admin.gallery.create');
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'foto' => 'required'
        ]);
        $file = $request->file('foto');
        $filename = time() . '_' . $file->getClientOriginalName();
        Gallery::create([
            'foto' => $filename
        ]);
        $file->move('foto', $filename);
        session()->flash('succes', 'Berhasil Di Tambahkan');
        return redirect()->route('admin.gallery.index');
    }
    public function edit(Gallery  $gallery)
    {
        return view('admin.gallery.edit', [
            'gallery' => $gallery
        ]);
    }
    public function update(Request $request, Gallery $gallery)
    {
        $this->validate($request, [
            'foto' => 'required'
        ]);
        File::delete('foto/'.$gallery->foto);
        $file = $request->file('foto');
        $filename = time() . '_' . $file->getClientOriginalName();
        $gallery->update(['foto' => $filename]);
        $file->move('foto', $filename);
        session()->flash('succes', 'berhasil diupdate');
        return redirect()->route('admin.gallery.index');
    }
    public function destroy(Gallery $gallery)
    {
        File::delete('foto/' . $gallery->foto);
        $gallery->delete();
        session()->flash('succes', 'berhasil dihapus');
        return redirect()->route('admin.gallery.index');
    }
}
