<?php

namespace App\Http\Controllers;
use App\Profile;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function index()
    {
        return view('admin.profile.index',[
            'profile' => Profile::all()
        ]);
    }

    public function create()
    {
        return view ('admin.profile.create');
    }

    public function store (Request $request)
    {
        $this -> validate($request,[
            'p1' => 'required',
            'p2' => 'required',
            'visi' => 'required',
            'misi' => 'required'
        ]);
        Profile::create($request->all());
        session()->flash('succes','Berhasil Di Tambahkan');
        return redirect()->route('admin.profile.index');
    }
    public function edit(Profile  $profile)
    {
        return view('admin.profile.edit',[
            'profile' => $profile
        ]);
    }
    public function update(Request $request,Profile $profile)
    {
        $this->validate($request,[
            'p1' => 'required',
            'p2' => 'required',
            'visi' => 'required',
            'misi' => 'required'
        ]);

        $profile->update($request->all());

        session()->flash('succes','berhasil diupdate');

        return redirect()->route('admin.profile.index');
    }
    public function destroy(Profile $profile)
    {
        $profile->delete();
        session()->flash('succes','berhasil dihapus');
        return redirect()->route('admin.profile.index');
    }
}
