<?php

namespace App\Http\Controllers;

use App\News;
use Illuminate\Http\Request;
use File;

class NewsController extends Controller
{
    public function index()
    {
        return view('admin.news.index', [
            'news' => News::all()
        ]);
    }

    public function create()
    {
        return view('admin.news.create');
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'foto' => 'required',
            'judul' => 'required',
            'deskripsi' => 'required'
        ]);
        $file = $request->file('foto');
        $filename = time() . '_' . $file->getClientOriginalName();
        News::create([
            'foto' => $filename,
            'judul' => $request->judul,
            'deskripsi' => $request->deskripsi
        ]);
        $file->move('foto', $filename);
        session()->flash('succes', 'Berhasil Di Tambahkan');
        return redirect()->route('admin.news.index');
    }
    public function edit(News  $news)
    {
        return view('admin.news.edit', [
            'news' => $news
        ]);
    }
    public function update(Request $request, News $news)
    {
        $this->validate($request, [
            'foto' => 'required',
            'judul' => 'required',
            'deskripsi' => 'required'
        ]);
        File::delete('foto/'.$news->foto);
        $file = $request->file('foto');
        $filename = time() . '_' . $file->getClientOriginalName();
        $news->update(['foto' => $filename,  'judul' => $request->judul,    'deskripsi' => $request->deskripsi]);
        $file->move('foto', $filename);
        session()->flash('succes', 'berhasil diupdate');
        return redirect()->route('admin.news.index');
    }
    public function destroy(News $news)
    {
        File::delete('foto/' . $news->foto);
        $news->delete();
        session()->flash('succes', 'berhasil dihapus');
        return redirect()->route('admin.news.index');
    }
}
