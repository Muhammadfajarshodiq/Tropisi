<?php

namespace App\Http\Controllers;
use App\Contact;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    //
    public function index()
    {
        return view('admin.contact.index',[
            'contact' => Contact::all()
        ]);
    }

    public function create()
    {
        return view ('admin.contact.create');
    }

    public function store (Request $request)
    {
        $this -> validate($request,[
            'email' => 'required',
            'no' => 'required',
            'lokasi' => 'required'
        ]);
        Contact::create($request->all());
        session()->flash('succes','Berhasil Di Tambahkan');
        return redirect()->route('admin.contact.index');
    }
    public function edit(Contact  $contact)
    {
        return view('admin.contact.edit',[
            'contact' => $contact
        ]);
    }
    public function update(Request $request,Contact $contact)
    {
        $this->validate($request,[
            'email' => 'required',
            'no' => 'required',
            'lokasi' => 'required'
        ]);

        $contact->update($request->all());

        session()->flash('succes','berhasil di update');

        return redirect()->route('admin.contact.index');
    }
    public function destroy(Contact $contact)
    {
        $contact->delete();
        session()->flash('succes','berhasil dihapus');
        return redirect()->route('admin.contact.index');
    }

}
