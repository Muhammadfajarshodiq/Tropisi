<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Profile;
use App\News;
use App\Contact;
use App\Gallery;
use App\Message;

use PhpParser\Node\Expr\AssignOp\Concat;

class MainController extends Controller
{
    //
    public function home()
    {
        return view('main.home',[
            'profile' => Profile::all(),
            'news' => News::paginate(6),
            'gallery' => Gallery::all(),
            'contact' => Contact::all()
        ]);
    }

    public function profile()
    {
        return view('main.about',[
            'about' => Profile::all(),
            'contact' => Contact::all()
        ]);  
    }

    public function news()
    {
        return view('main.news',[
            'news' => News::paginate(6),
            'contact' => Contact::all()
        ]);   
    }

    public function gallery()
    {
        return view('main.gallery',[
            'gallery' => Gallery::all(),
            'contact' => Contact::all()
        ]);
    }

    public function contact()
    {
        return view('main.contact',[
            'contact' => Contact::all(),
            'contact' => Contact::all()
        ]);
    }

    public function store(Request $request){
        $this -> validate($request,[
            'email' => 'required',
            'nama' => 'required',
            'subject' => 'required',
            'deskripsi' => 'required'
        ]);
        Message::create($request->all());
        session()->flash('succes','Berhasil Dikirim');
        return redirect()->route('main.contact');
    }

}
