@guest
<script>
    window.onload = function() {
        document.location.href = '/'
    }
</script>
@endguest
<!-- @auth -->
@extends('layouts.app')
@section('content')
<div class="container">
    <div class="d-flex mb-2">
        <a href="{{ route('admin.news.create') }}"><button {{ count($news) == 6 ? 'disabled' : '' }} class="btn btn-success" style="width: 100px;">Add</button></a>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="table-reponsive">
                <table class="table table-primay">
                    <thead style="background-color: #aeaeae;">
                        <tr>
                            <th>#</th>
                            <th>Foto</th>
                            <th>Judul</th>
                            <th>Deskripsi</th>
                            <th>Option</th>
                        </tr>
                    </thead>
                    @php 
                        $no = 1; 
                    @endphp
                    @forelse ($news as $data)
                    <tr>
                        <th>{{ $no++ . '.' }}</th>
                        <td><img src="{{ asset('foto/'.$data->foto) }} " width="50" height="50"></td>
                        <td>{{ $data->judul}}</td>
                        <td>{{ $data->deskripsi}}</td>
                        <td>
                            <a href="{{ route('admin.news.edit', $data->id ) }} " class="btn btn-info float-left mr-2" style="width: 70px;">Edit</a>
                            <form action="{{ route('admin.news.destroy', $data->id) }}" method="post">
                                @csrf
                                @method('delete')
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda Yakin?');">Delete</button>
                            </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5">
                            <div class="alert alert-warning">
                                <h2>There Is No Data</h2>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
<!-- @endauth -->