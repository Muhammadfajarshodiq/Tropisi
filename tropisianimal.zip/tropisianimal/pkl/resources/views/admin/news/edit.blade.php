@guest
<script>
    window.onload = function() {
        document.location.href = '/'
    }
</script>
@endguest
<!-- @auth -->
@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card" style="background-color: #a9a8a8; color: black;">
                <form action="{{ route('admin.news.update', $news->id )}}" method="post" enctype="multipart/form-data">
                <div class="card-body">
                @csrf    
                @method('patch')
                        <div class="form-group">
                            <label for="foto">Foto</label>
                            <input class="form-control" type="file" name="foto" id="foto">
                        </div>
                        <div class="form-group">
                            <label for="judul">Judul</label>
                            <textarea name="judul" id="judul" class="form-control">{{ $news->judul }}</textarea>
                        </div>
                        <div class="form-group">
                            <label for="deskripsi">Deskripsi</label>
                            <textarea name="deskripsi" id="deskripsi" class="form-control">{{ $news->deskripsi }}</textarea>
                        </div>
                </div>
                <div class="card-footer">
                    <button class="btn btn-primary" style="width: 100px;" type="submit">Update</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
<!-- @endauth -->