@guest
<script>
    window.onload = function() {
        document.location.href = '/'
    }
</script>
@endguest
<!-- @auth -->
@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="table-reponsive">
                <table class="table">
                    <thead style="background-color: #aeaeae;">
                        <tr>
                            <th>Email</th>
                            <th>Name</th>
                            <th>Subject</th>
                            <th>Deskripsi</th>
                            <th colspan="2">Option</th>
                        </tr>
                    </thead>
                    @forelse ($messages as $data)
                    <tr>
                        <td>{{ $data->email}}</td>
                        <td>{{ $data->nama}}</td>
                        <td>{{ $data->subject}}</td>
                        <td>{{ $data->deskripsi}}</td>
                        <td><form action="{{ route('admin.message.destroy', $data->id) }}" method="post">
                                @csrf
                                @method('delete')
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda Yakin?');">Delete</button>
                            </form></td>

                    </tr>
                    @empty
                    <tr>
                        <td colspan="5">
                            <div class="alert alert-warning">
                                <h2>There Is No Data</h2>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
<!-- @endauth -->