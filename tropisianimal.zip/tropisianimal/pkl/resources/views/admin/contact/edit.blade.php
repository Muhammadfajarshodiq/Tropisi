@guest
<script>
    window.onload = function() {
        document.location.href = '/'
    }
</script>
@endguest
<!-- @auth -->
@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card" style="background-color: #a9a8a8; color: black;">
                <form action="{{ route('admin.contact.update', $contact->id) }}" method="post">
                <div class="card-body">
                @csrf    
                @method('patch')
                        <div class="form-group">
                            <label for="email">Email</label>
                            <textarea name="email" id="email" class="form-control">{{ $contact->email }}</textarea>
                        </div>
                        <div class="form-group">
                            <label for="no">No</label>
                            <textarea name="no" id="no" class="form-control">{{ $contact->no }}</textarea>
                        </div>
                        <div class="form-group">
                            <label for="lokasi">Lokasi</label>
                            <textarea name="lokasi" id="lokasi" class="form-control">{{ $contact->lokasi }}</textarea>
                        </div>
                </div>
                <div class="card-footer">
                    <button class="btn btn-primary" type="submit">Update</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
<!-- @endauth -->