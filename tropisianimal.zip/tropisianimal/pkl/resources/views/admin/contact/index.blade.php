@guest
<script>
    window.onload = function() {
        document.location.href = '/'
    }
</script>
@endguest
<!-- @auth -->
@extends('layouts.app')
@section('content')
<div class="container">
    <div class="d-flex mb-2">
        <a href="{{ route('admin.contact.create') }}"><button {{ count($contact) == 1 ? 'disabled' : '' }} class="btn btn-success" style="width: 100px;">Add</button></a>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="table-reponsive">
                <table class="table table-primay">
                    <thead style="background-color: #aeaeae;">
                        <tr>
                            <th>Email</th>
                            <th>No</th>
                            <th>Lokasi</th>
                            <th colspan="2">Option</th>
                        </tr>
                    </thead>
                    @forelse ($contact as $data)
                    <tr>
                        <td>{{ $data->email}}</td>
                        <td>{{ $data->no}}</td>
                        <td>{{ $data->lokasi}}</td>
                        <td><a href="{{ route('admin.contact.edit', $data->id ) }} " style="width: 70px;"  class="btn btn-info">Edit</a></td>

                    </tr>
                    @empty
                    <tr>
                        <td colspan="5">
                            <div class="alert alert-warning">
                                <h2>There Is No Data</h2>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
<!-- @endauth -->