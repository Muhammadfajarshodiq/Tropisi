@guest
<script>
    window.onload = function() {
        document.location.href = '/'
    }
</script>
@endguest
<!-- @auth -->
@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card">
                <form action="{{ route('admin.gallery.store') }}" method="post" enctype="multipart/form-data">
                <div class="card-body">
                @csrf    
                        <div class="form-group">
                            <label for="foto">Foto</label>
                            <input class="form-control" type="file" name="foto" id="foto">
                        </div>
                </div>
                <div class="card-footer">
                    <button class="btn btn-primary" type="submit">Store</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
<!-- @endauth -->