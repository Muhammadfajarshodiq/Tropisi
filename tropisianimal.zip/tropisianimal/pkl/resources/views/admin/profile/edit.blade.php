@guest
<script>
    window.onload = function() {
        document.location.href = '/'
    }
</script>
@endguest
<!-- @auth -->
@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card" style="background-color: #a9a8a8; color: black;">
                <form action="{{ route('admin.profile.update', $profile->id) }}" method="post">
                <div class="card-body">
                @csrf    
                @method('patch')
                        <div class="form-group">
                            <label for="p1">Paragraf 1</label>
                            <textarea name="p1" id="p1" class="form-control">{{ $profile->p1 }}</textarea>
                        </div>
                        <div class="form-group">
                            <label for="p2">Paragraf 2</label>
                            <textarea name="p2" id="p2" class="form-control">{{ $profile->p2 }}</textarea>
                        </div>
                        <div class="form-group">
                            <label for="visi">Visi</label>
                            <textarea name="visi" id="visi" class="form-control">{{ $profile->visi }}</textarea>
                        </div>
                        <div class="form-group">
                            <label for="misi">Misi</label>
                            <textarea name="misi" id="misi" class="form-control">{{ $profile->misi }}</textarea>
                        </div>
                </div>
                <div class="card-footer">
                    <button class="btn btn-primary" type="submit">Update</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
<!-- @endauth -->