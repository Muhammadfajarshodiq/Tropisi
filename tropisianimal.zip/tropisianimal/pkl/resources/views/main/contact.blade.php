@extends('../main/index')
@section('content')
<style>
section,
footer{
    padding : 50px 0px;
}

.slides img{
        filter : brightness(50%)
    }
</style>
<div class="slider" id="home">
        <ul class="slides">
            <li>
                <img src="{{ asset('asset/ASET/x1/pascal-muller-iSz0IMtulos-unsplash.png') }}">
                <div class="caption left-align">
                    <h3>Kontak Kami</h3>
                </div>
            </li>
        </ul>
    </div>

<section>
    <div class="container">
        <div class="row">
            <div class="col m12">
                <img src="{{ asset('asset/ASET/x1/1_qYUvh-EtES8dtgKiBRiLsA.png') }}" class="responsive-img">
            </div>
        </div>
    </div>
</section>
<section>
        <div class="container">
            <h3>Contact Us</h3>
            <div class="row">
                <form method="post" action="{{'contact_send'}}">
                    @csrf
                <div class="col m6">
                <div class="card-panel">
                    <div class="input-field">
                        <textarea name="deskripsi" id="deskripsi" class="materialize-textarea validate" required></textarea>
                        <label for="deskripsi">Deskripsi</label>
                    </div>
                </div>
                </div>
                <div class="col m6 s12">
                        <div class="card-panel">
                            <h5>Please Fil out This Form</h5>
                            <div class="input-field">
                                <input type="text" name="nama" id="name" required class="validate">
                                <label for="name">Name</label>
                            </div>
                            <div class="input-field">
                                <input type="email" name="email" id="email" class="validate">
                                <label for="email">Email</label>
                            </div>
                            <div class="input-field">
                                <input type="text" name="subject" id="subject" class="validate" required>
                                <label for="subject">subject</label>
                            </div>
                            
                            <button class="btn blue darken-2">Send</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
@endsection
<!-- <div class="col m6 s12">
                    <div class="card-panel blue darken-2 center white-text">
                        <i class="material-icons">email</i>
                        <h5>Contact</h5>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. </p>
                    </div>
                    <ul class="collection with-header">
                        <li class="collection-header"><h4>Our Office</h4></li>
                        <li class="collection-item">MacroTeam</li>
                        <li class="collection-item">Kp.pos Bojonggede 03/01 Bogor</li>
                        <li class="collection-item">West Java, Indonesia</li>
                    </ul>
                </div> -->
@foreach($contact as $data)
@section('email',$data->email)
@section('telepon',$data->no)
@section('lokasi',$data->lokasi)
@endforeach