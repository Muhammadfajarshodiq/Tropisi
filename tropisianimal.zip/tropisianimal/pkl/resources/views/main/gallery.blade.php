@extends('../main/index')
@section('content')
<style>
section,
footer{
    padding : 50px 0px;
}

.slides img{
        filter : brightness(50%)
    }
    #img{
        height: 150px;
        width: 220px;
    }
</style>
<div class="slider" id="home">
        <ul class="slides">
            <li>
                <img src="{{ asset('asset/ASET/x1/pascal-muller-iSz0IMtulos-unsplash.png') }}">
                <div class="caption left-align">
                    <h3>Galeri</h3>
                </div>
            </li>
        </ul>
    </div>

    <section>
    
    <div class="container">
        <div class="row">
            <div class="col m12">
                <img src="{{ asset('asset/ASET/x1/Group 77.png') }}" class="responsive-img materialboxed">
            </div>
        </div>
        <div class="row">
            @foreach($gallery as $data)
            <div class="col m3">
                <img src="{{ asset('foto/'.$data->foto) }}" id="img" class="responsive-img materialboxed">
                <br>
            </div>
            @endforeach
        </div>
    </div>
    </section>
    <script>
        let slider1 = document.querySelector('.slider1');
        M.Slider.init(slider1,{
            
        });
    </script>
@endsection

@foreach($contact as $data)
@section('email',$data->email)
@section('telepon',$data->no)
@section('lokasi',$data->lokasi)
@endforeach