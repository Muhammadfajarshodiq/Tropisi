
<?php $__env->startSection('content'); ?>
<style>
    section,
    footer {
        padding: 50px 0px;
    }

    .parallax img,
    .slides img {
        filter: brightness(80%)
    }

    .carousel .carousel-item {
        width: 25%;
        height : auto;
    }
</style>
<div class="slider" id="home">
    <ul class="slides">
        <li>
            <img src="<?php echo e(asset('asset/ASET/x1/pascal-muller-iSz0IMtulos-unsplash.png')); ?>">
            <div class="caption left-align">
                <div class="row">
                    <div class="col m5">
                        <h3>Hewan<br>Tropis di Dunia</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae aliquam architecto quis labore sit nemo voluptates mollitia suscipit voluptate facilis</p>
                    </div>
                </div>
            </div>
        </li>
    </ul>
</div>

<!-- about us -->
<section>
    <div class="container">
        <div class="row">
            <div class="col m6">
                <?php $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <strong class="green-text">Tropisianimal</strong>
                <h3>Membangun Komunitas Hewan</h3>
                <p><?php echo e($data->p1); ?></p>
                <p><?php echo e($data->p2); ?></p>
                <a href="<?php echo e(route('main.profile')); ?>" class="sidenav-trigger waves-effect waves-light btn green darken-2 button">Baca Selengkapnya<i class="material-icons right">arrow_forward</i></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col m3 light">
                <br>
                <img src="<?php echo e(asset('asset/ASET/x1/alessandro-desantis-9_9hzZVjV8s-unsplash.png')); ?>" alt="" class="responsive-img materialboxed">
            </div>
            <div class="col m3">
                <br>
                <img src="<?php echo e(asset('asset/ASET/x1/joshua-j-cotten-VCzNXhMoyBw-unsplash.png')); ?>" alt="" class="responsive-img materialboxed">
            </div>
            <div class="row">
                <div class="col m6">
                    <br>
                    <img src="<?php echo e(asset('asset/ASET/x1/kyle-nieber-3ryX0ShTMWg-unsplash.png')); ?>" alt="" class="responsive-img materialboxed">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Clients -->
<section>
    <div class="parallax-container">
        <div class="parallax"><img src="<?php echo e(asset('asset/ASET/x1/juliana-castro-LdEZjO3wjqQ-unsplash.png')); ?>"></div>
        <div class="container">
            <h3 class="white-text">Kami Membawa Anda <br> Untuk Mengetahui Lebih Dalam</h3>
            <div class="row">
                <div class="col m3 s2 center">
                    <div class="card-panel center">
                        <i class="material-icons medium green-text">pets</i>
                        <h6>Lorem Ipsum</h6>
                        <p class="grey-text">Lorem ipsum dolor, sit amet</p>
                    </div>
                </div>
                <div class="col m3 s2 center">
                    <div class="card-panel center">
                        <i class="material-icons medium green-text">pets</i>
                        <h6>Lorem Ipsum</h6>
                        <p class="grey-text">Lorem ipsum dolor, sit amet</p>
                    </div>
                </div>
                <div class="col m3 s2 center">
                    <div class="card-panel center">
                        <i class="material-icons medium green-text">pets</i>
                        <h6>Lorem Ipsum</h6>
                        <p class="grey-text">Lorem ipsum dolor, sit amet</p>
                    </div>
                </div>
                <div class="col m3 s2 center">
                    <div class="card-panel center">
                        <i class="material-icons medium green-text">pets</i>
                        <h6>Lorem Ipsum</h6>
                        <p class="grey-text">Lorem ipsum dolor, sit amet</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Services -->
<!-- PortFolio -->
<section>
    <div class="container">
        <strong class="green-text">BERITA</strong>
        <h3 class="">Baca Berita Terbaru Kami <br> Dalam Tropisianimal</h3>
        <div class="row">
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col m4 s12">
                <div class="card" style="height: 350px; overflow:hidden;">
                    <div class="card-image">
                        <img src="<?php echo e(asset('foto/'.$data->foto)); ?>" style="width: 100%; height: 200px; object-fit: cover;" class="responsive-img materialboxed">
                    </div>
                    <div class="card-content waves-effect waves-dark">
                        <h6><?php echo e($data->judul); ?></h6>
                        <p class="light grey-text darken-2"><?php echo e($data->deskripsi); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
    
</section>
<div class="container">
    <div class="row">
        <div class="col m12">
            <strong class="green-text">GALERI</strong>
            <h3>Lihat Lebih Banyak Hewan Tropis <br> Pada Galeri Kami</h3>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="carousel">
        <div class="col m12" style="width: 100%; height: 100%">
            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="carousel-item" href="#one!"><img src="<?php echo e(asset('foto/'.$data->foto)); ?>" class="responsive-img"></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!-- Contact -->

<?php $__env->stopSection(); ?>
<?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('email',$data->email); ?>
<?php $__env->startSection('telepon',$data->no); ?>
<?php $__env->startSection('lokasi',$data->lokasi); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->make('main.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pkl\resources\views/main/home.blade.php ENDPATH**/ ?>