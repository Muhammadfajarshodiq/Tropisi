<?php if(auth()->guard()->guest()): ?>
<script>
    window.onload = function() {
        document.location.href = '/'
    }
</script>
<?php endif; ?>
<!-- <?php if(auth()->guard()->check()): ?> -->

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex mb-2">

        <a href="<?php echo e(route('admin.gallery.create')); ?>"><button <?php echo e(count($gallery) == 12 ? 'disabled' : ''); ?> class="btn btn-success" style="width: 100px;">Add</button></a>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="table-responsive">
                <table class="table table-light">
                    <thead style="background-color: #aeaeae;">
                        <tr>
                            <th>#</th>
                            <th>Foto</th>
                            <th>Option</th>
                        </tr>
                    </thead>
                    <?php 
                    $no = 1;
                    ?>
                    <?php $__empty_1 = true; $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th><?php echo e($no++ . '.'); ?></th>
                        <td><img src="<?php echo e(asset('foto/'.$data->foto)); ?> " width="50" height="50"></td>
                        <td><a href="<?php echo e(route('admin.gallery.edit', $data->id )); ?> " class="btn btn-info float-left mr-2" style="width: 70px;">Edit</a>
                            <form action="<?php echo e(route('admin.gallery.destroy', $data->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submi" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3">
                            <div class="alert alert-warning">
                                <h2>There Is No Data</h2>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<!-- <?php endif; ?> -->
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pkl\resources\views/admin/gallery/index.blade.php ENDPATH**/ ?>