<nav class="navbar navbar-expand-md navbar-dark bg-dark shadow-sm">
  <div class="container">
    <a class="navbar-brand text-light">
      Tropisianimal
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" data-target="#navbarCollapse" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse show" id="navbarCollapse">
      <!-- Left Side Of Navbar -->

      <!-- Right Side Of Navbar -->
      <ul class="navbar-nav ml-auto">
        <!-- Authentication Links -->

        <?php if(auth()->guard()->guest()): ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
        </li>
        <!-- <?php if(Route::has('register')): ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
        </li>
        <?php endif; ?> -->
        <?php else: ?>
        <li class="nav-item">
          <a class="nav-link<?php echo e(request()->is('admin/profile') ? ' active' : ''); ?> " href="<?php echo e(route('admin.profile.index')); ?>">Profile</a>
        </li>
        <li class="nav-item">
          <a class="nav-link<?php echo e(request()->is('admin/news') ? ' active' : ''); ?> " href="<?php echo e(route('admin.news.index')); ?>">News</a>
        </li>
        <li class="nav-item">
          <a class="nav-link<?php echo e(request()->is('admin/gallery') ? ' active' : ''); ?> " href="<?php echo e(route('admin.gallery.index')); ?>">Gallery</a>
        </li>
        <li class="nav-item">
          <a class="nav-link<?php echo e(request()->is('admin/contact') ? ' active' : ''); ?> " href="<?php echo e(route('admin.contact.index')); ?>">Contact</a>
        </li>
        <li class="nav-item">
          <a class="nav-link<?php echo e(request()->is('admin/message') ? ' active' : ''); ?> " href="<?php echo e(route('admin.message.index')); ?>">Message</a>
        </li>
        <li class="nav-item dropdown">
          <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
            <?php echo e(Auth::user()->name); ?>

          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
              <?php echo e(__('Logout')); ?>

            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
              <?php echo csrf_field(); ?>
            </form>
          </div>
        </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav><?php /**PATH C:\laragon\www\pkl\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>