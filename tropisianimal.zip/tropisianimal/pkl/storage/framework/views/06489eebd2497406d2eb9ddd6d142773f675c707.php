
<?php $__env->startSection('content'); ?>
<style>
section,
footer{
    padding : 50px 0px;
}

.slides img{
        filter : brightness(50%)
    }
    #img{
        height: 150px;
        width: 220px;
    }
</style>
<div class="slider" id="home">
        <ul class="slides">
            <li>
                <img src="<?php echo e(asset('asset/ASET/x1/pascal-muller-iSz0IMtulos-unsplash.png')); ?>">
                <div class="caption left-align">
                    <h3>Galeri</h3>
                </div>
            </li>
        </ul>
    </div>

    <section>
    
    <div class="container">
        <div class="row">
            <div class="col m12">
                <img src="<?php echo e(asset('asset/ASET/x1/Group 77.png')); ?>" class="responsive-img materialboxed">
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col m3">
                <img src="<?php echo e(asset('foto/'.$data->foto)); ?>" id="img" class="responsive-img materialboxed">
                <br>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    </section>
    <script>
        let slider1 = document.querySelector('.slider1');
        M.Slider.init(slider1,{
            
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('email',$data->email); ?>
<?php $__env->startSection('telepon',$data->no); ?>
<?php $__env->startSection('lokasi',$data->lokasi); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->make('../main/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pkl\resources\views/main/gallery.blade.php ENDPATH**/ ?>