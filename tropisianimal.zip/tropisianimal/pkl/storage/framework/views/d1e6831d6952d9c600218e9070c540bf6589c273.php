<?php if(auth()->guard()->guest()): ?>
<script>
    window.onload = function() {
        document.location.href = '/'
    }
</script>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card" style="background-color: #a9a8a8; color: black;">
                <form action="<?php echo e(route('admin.news.store')); ?>" method="post" enctype="multipart/form-data">
                <div class="card-body">
                <?php echo csrf_field(); ?>    
                        <div class="form-group">
                            <label for="foto">Foto</label>
                            <input class="form-control" type="file" name="foto" id="foto">
                        </div>
                        <div class="form-group">
                            <label for="judul">Judul</label>
                            <textarea name="judul" id="judul" class="form-control"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="deskripsi">Deskripsi</label>
                            <textarea name="deskripsi" id="deskripsi" class="form-control"></textarea>
                        </div>
                </div>
                <div class="card-footer">
                    <button class="btn btn-primary" type="submit" style="width: 100px; ">Store</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pkl\resources\views/admin/news/create.blade.php ENDPATH**/ ?>