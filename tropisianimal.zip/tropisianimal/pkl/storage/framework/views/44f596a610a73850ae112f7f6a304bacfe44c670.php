<footer class="bg-dark text-light p-5">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                Muhammad Fajar Sahodiq
            </div>
            <div class="col-md-3">
                Muhammad Fajar Sahodiq
            </div>
            <div class="col-md-3">
                Muhammad Fajar Sahodiq
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\pkl\resources\views/layout/footer.blade.php ENDPATH**/ ?>