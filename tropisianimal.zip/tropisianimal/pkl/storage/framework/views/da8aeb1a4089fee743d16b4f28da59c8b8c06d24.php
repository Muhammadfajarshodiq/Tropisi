<?php if(auth()->guard()->guest()): ?>
<script>
    window.onload = function() {
        document.location.href = '/'
    }
</script>
<?php endif; ?>
<!-- <?php if(auth()->guard()->check()): ?> -->

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex mb-2">
        <a href="<?php echo e(route('admin.news.create')); ?>"><button <?php echo e(count($news) == 6 ? 'disabled' : ''); ?> class="btn btn-success" style="width: 100px;">Add</button></a>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="table-reponsive">
                <table class="table table-primay">
                    <thead style="background-color: #aeaeae;">
                        <tr>
                            <th>#</th>
                            <th>Foto</th>
                            <th>Judul</th>
                            <th>Deskripsi</th>
                            <th>Option</th>
                        </tr>
                    </thead>
                    <?php 
                        $no = 1; 
                    ?>
                    <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th><?php echo e($no++ . '.'); ?></th>
                        <td><img src="<?php echo e(asset('foto/'.$data->foto)); ?> " width="50" height="50"></td>
                        <td><?php echo e($data->judul); ?></td>
                        <td><?php echo e($data->deskripsi); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.news.edit', $data->id )); ?> " class="btn btn-info float-left mr-2" style="width: 70px;">Edit</a>
                            <form action="<?php echo e(route('admin.news.destroy', $data->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda Yakin?');">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5">
                            <div class="alert alert-warning">
                                <h2>There Is No Data</h2>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<!-- <?php endif; ?> -->
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pkl\resources\views/admin/news/index.blade.php ENDPATH**/ ?>