
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card">
                <form action="<?php echo e(route('admin.profile.store')); ?>" method="post">
                <div class="card-body">
                <?php echo csrf_field(); ?>    
                        <div class="form-group">
                            <label for="p1">Paragraf 1</label>
                            <textarea name="p1" id="p1" class="form-control"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="p2">Paragraf 2</label>
                            <textarea name="p2" id="p2" class="form-control"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="visi">Visi</label>
                            <textarea name="visi" id="visi" class="form-control"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="misi">Misi</label>
                            <textarea name="misi" id="misi" class="form-control"></textarea>
                        </div>
                </div>
                <div class="card-footer">
                    <button class="btn btn-primary" type="submit">Store</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pkl\resources\views/admin/profile/create.blade.php ENDPATH**/ ?>