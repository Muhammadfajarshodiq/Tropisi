<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tropisianimal</title>
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/bootstrap.css')); ?>">
</head>
<body>
    <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <div class="pb-5 pt-5">
    <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('asset/css/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/bootstrap.js')); ?>"></script>
</body>
</html><?php /**PATH C:\laragon\www\pkl\resources\views/layout/app.blade.php ENDPATH**/ ?>