
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card">
                <form action="<?php echo e(route('admin.contact.store')); ?>" method="post">
                <div class="card-body">
                <?php echo csrf_field(); ?>    
                        <div class="form-group">
                            <label for="email">Email</label>
                            <textarea name="email" id="email" class="form-control"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="no">No</label>
                            <textarea name="no" id="no" class="form-control"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="lokasi">lokasi</label>
                            <textarea name="lokasi" id="lokasi" class="form-control"></textarea>
                        </div>
                </div>
                <div class="card-footer">
                    <button class="btn btn-primary" type="submit">Store</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pkl\resources\views/admin/contact/create.blade.php ENDPATH**/ ?>