
<?php $__env->startSection('content'); ?>
<style>
    section,footer{
        padding : 50px 0px;
    }
    .slides img{
        filter : brightness(50%)
    }
</style>
<?php $__empty_1 = true; $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="slider" id="home">
        <ul class="slides">
            <li>
                <img src="<?php echo e(asset('asset/ASET/x1/pascal-muller-iSz0IMtulos-unsplash.png')); ?>">
                <div class="caption left-align">
                    <h3>Tentang Kami</h3>
                </div>
            </li>
        </ul>
    </div>
    <section>
        <div class="container">
            <div class="row">
                <div class="col m6">
                    <h3>Tropisianimal</h3>
                    <p><?php echo e($data->p1); ?></p>
                    <p><?php echo e($data->p2); ?></p>
                </div>
                <div class="col m3">
                    <br>
                    <img src="<?php echo e(asset('asset/ASET/x1/kyaw-tun-_YIX48_4hgs-unsplash.png')); ?>" class="responsive-img materialboxed">
                </div>
                <div class="col m3">
                    <br>
                    <img src="<?php echo e(asset('asset/ASET/x1/dawn-armfield-84n7c9cLEKM-unsplash.png')); ?>" class="responsive-img materialboxed">
                </div>
                <div class="row">
                    <div class="col m6">
                        <br>
                        <img src="<?php echo e(asset('asset/ASET/x1/smit-patel-dGMcpbzcq1I-unsplash.png')); ?>" class="responsive-img materialboxed">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container">
            <div class="row">
                <h3>Visi</h3>
                <p><?php echo e($data->visi); ?></p>
            </div>
            <div class="row">
                <h3>Misi</h3>
                <p><?php echo e($data->misi); ?></p>
            </div>
        </div>
    </section>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="card-panel yellow darken-2">
        <div class="card-content center">
            <h2>Tidak Ada Konten</h2>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('email',$data->email); ?>
<?php $__env->startSection('telepon',$data->no); ?>
<?php $__env->startSection('lokasi',$data->lokasi); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->make('../main/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pkl\resources\views/main/about.blade.php ENDPATH**/ ?>