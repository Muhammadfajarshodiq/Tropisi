<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Muhammad Fajar Shodiq</title>
    <link rel="stylesheet" href="<?php echo e(asset('materialize/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('materialize/css/materialize.min.css')); ?>">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

</head>
<body>
<!-- navbar -->
    <div class="navbar-fixed">
        <nav class="green">
          <div class="container">
              <div class="nav-wrapper">
                    <a href="<?php echo e(route('main.home')); ?>" class="brand-logo"><img src="<?php echo e(asset('asset/ASET/x1/Tropisianimal.png')); ?>"></a>
                    <a href="#" data-target="mobile-nav" class="sidenav-trigger"><i class="material-icons">more_vert</i></a>
                    <ul class="right hide-on-med-and-down navs">
                        <li><a href="<?php echo e(route('main.home')); ?>">Home</a></li>
                        <li><a href="<?php echo e(route('main.profile')); ?>">About</a></li>
                        <li><a href="<?php echo e(route('main.news')); ?>">News</a></li>
                        <li><a href="<?php echo e(route('main.gallery')); ?>">Gallery</a></li>
                        <li><a href="<?php echo e(route('main.contact')); ?>">Contact</a></li>
                    </ul>
                </div>
            </div>
        </nav>
      </div>
       <!-- sidebar -->
    <ul class="sidenav" id="mobile-nav">
        <li><a href="<?php echo e(route('main.home')); ?>">HOME</a></li>
        <li><a href="<?php echo e(route('main.profile')); ?>">ABOUT</a></li>
        <li><a href="<?php echo e(route('main.news')); ?>">NEWS</a></li>
        <li><a href="<?php echo e(route('main.gallery')); ?>">GALLERY</a></li>
        <li><a href="<?php echo e(route('main.contact')); ?>">CONTACT</a></li>
    </ul>

    <!-- slider -->
    <?php echo $__env->yieldContent('content'); ?>
    <footer class="grey darken-4 white-text">
        <div class="container">
        <div class="row">
            <div class="col m3 offset-m1">
                <h6>Tropisianimal</h6>
                <p class="light grey-text darken-2">Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus laborum, deleniti cumque error tenetur nihil. Aspernatur magnam minima dicta ipsam dolorum iste fugit quam adipisci culpa? Soluta architecto voluptatum eius.</p>
                <img src="<?php echo e(asset('asset/ASET/x1/001-facebook.png')); ?>" alt="">
                <img src="<?php echo e(asset('asset/ASET/x1/002-twitter.png')); ?>" alt="">
            </div>
            
            <div class="col m2">
                <h6>Useful links</h6>
                <ul class="list">
                    <li><a href=""><strong class="white-text">Blog</strong></a></li>
                    <li><a href=""><strong class="white-text">Hewan</strong></a></li>
                    <li><a href=""><strong class="white-text">Galeri</strong></a></li>
                    <li><a href=""><strong class="white-text">Testimonial</strong></a></li>
                </ul>
            </div>
            <div class="col m2">
            <h6>Privacy</h6>
            <ul class="list">
                    <li><a href=""><strong class="white-text">Karir</strong></a></li>
                    <li><a href=""><strong class="white-text">Tentang Kami</strong></a></li>
                    <li><a href=""><strong class="white-text">Kontak Kami</strong></a></li>
                    <li><a href=""><strong class="white-text">Servis</strong></a></li>
                </ul>
            </div>
            <div class="col m3">
                <h6>Contact</h6>
                <ul class="list">
                    <li><a href=""><i class="material-icons left white-text" style="font-size : large">email <strong style="font-size : medium"><?php echo $__env->yieldContent('email'); ?></strong></i></a></li>
                    <li><a href=""><i class="material-icons left white-text" style="font-size : large">phone <strong style="font-size : medium"><?php echo $__env->yieldContent('telepon'); ?></strong></i></a></li>
                    <li><a href=""><i class="material-icons left white-text" style="font-size : large">place <strong style="font-size : medium"><?php echo $__env->yieldContent('lokasi'); ?></strong></i></a></li>
                </ul>
            </div>
        </div>
        <div class="row center">
            <div class="col m12">
                <strong>Copyright 2020 All rights reserved</strong>
            </div>
        
        </div>
        </div>
    </footer>
    <script src="<?php echo e(asset('materialize/js/materialize.min.js')); ?>"></script>
    <script src="<?php echo e(asset('materialize/js/script.js')); ?>"></script>
</body>
</html><?php /**PATH C:\laragon\www\pkl\resources\views/main/index.blade.php ENDPATH**/ ?>