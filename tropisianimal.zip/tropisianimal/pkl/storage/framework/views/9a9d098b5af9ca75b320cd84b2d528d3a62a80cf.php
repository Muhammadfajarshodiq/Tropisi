<?php if(auth()->guard()->guest()): ?>
<script>
    window.onload = function() {
        document.location.href = '/'
    }
</script>
<?php endif; ?>
<!-- <?php if(auth()->guard()->check()): ?> -->

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="table-reponsive">
                <table class="table">
                    <thead style="background-color: #aeaeae;">
                        <tr>
                            <th>Email</th>
                            <th>Name</th>
                            <th>Subject</th>
                            <th>Deskripsi</th>
                            <th colspan="2">Option</th>
                        </tr>
                    </thead>
                    <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($data->email); ?></td>
                        <td><?php echo e($data->nama); ?></td>
                        <td><?php echo e($data->subject); ?></td>
                        <td><?php echo e($data->deskripsi); ?></td>
                        <td><form action="<?php echo e(route('admin.message.destroy', $data->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda Yakin?');">Delete</button>
                            </form></td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5">
                            <div class="alert alert-warning">
                                <h2>There Is No Data</h2>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<!-- <?php endif; ?> -->
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pkl\resources\views/admin/message/index.blade.php ENDPATH**/ ?>