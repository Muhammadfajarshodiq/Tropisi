<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="">Tropisianimal</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-link<?php echo e(request()->is('admin/profile') ? ' active' : ''); ?> " href="<?php echo e(route('admin.profile.index')); ?>">Profile</a>
      <a class="nav-link<?php echo e(request()->is('admin/news') ? ' active' : ''); ?> " href="<?php echo e(route('admin.news.index')); ?>">News</a>
      <a class="nav-link<?php echo e(request()->is('admin/gallery') ? ' active' : ''); ?> " href="<?php echo e(route('admin.gallery.index')); ?>">Gallery</a>
      <a class="nav-link<?php echo e(request()->is('admin/contact') ? ' active' : ''); ?> " href="<?php echo e(route('admin.contact.index')); ?>">Contact</a>
    </div>
  </div>
</nav><?php /**PATH C:\laragon\www\pkl\resources\views/layout/navbar.blade.php ENDPATH**/ ?>