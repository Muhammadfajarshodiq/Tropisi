<?php if(auth()->guard()->guest()): ?>
<script>
    window.onload = function() {
        document.location.href = '/'
    }
</script>
<?php endif; ?>
<!-- <?php if(auth()->guard()->check()): ?> -->

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="d-flex mb-2">
        <a href="<?php echo e(route('admin.profile.create')); ?>"><button <?php echo e(count($profile) == 1 ? 'disabled' : ''); ?> class="btn btn-success" style="width: 100px;">Add</button></a>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="table-reponsive">
                <table class="table table-light">
                    <thead style="background-color: #aeaeae;">
                        <tr>
                            <th>Paragraf 1</th>
                            <th>Paragraf 2</th>
                            <th>Visi</th>
                            <th>Misi</th>
                            <th>Option</th>
                        </tr>
                    </thead>
                        <?php $__empty_1 = true; $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($data->p1); ?></td>
                            <td><?php echo e($data->p2); ?></td>
                            <td><?php echo e($data->visi); ?></td>
                            <td><?php echo e($data->misi); ?></td>
                            <td><a href="<?php echo e(route('admin.profile.edit', $data->id )); ?> " style="width: 100px;" class="btn btn-info">Edit</a></td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5">
                                <div class="alert alert-warning">
                                    <h2>There Is No Data</h2>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<!-- <?php endif; ?> -->
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pkl\resources\views/admin/profile/index.blade.php ENDPATH**/ ?>