<?php if(auth()->guard()->guest()): ?>
<script>
    window.onload = function() {
        document.location.href = '/'
    }
</script>
<?php endif; ?>
<!-- <?php if(auth()->guard()->check()): ?> -->

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card" style="background-color: #a9a8a8; color: black;">
                <form action="<?php echo e(route('admin.profile.update', $profile->id)); ?>" method="post">
                <div class="card-body">
                <?php echo csrf_field(); ?>    
                <?php echo method_field('patch'); ?>
                        <div class="form-group">
                            <label for="p1">Paragraf 1</label>
                            <textarea name="p1" id="p1" class="form-control"><?php echo e($profile->p1); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="p2">Paragraf 2</label>
                            <textarea name="p2" id="p2" class="form-control"><?php echo e($profile->p2); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="visi">Visi</label>
                            <textarea name="visi" id="visi" class="form-control"><?php echo e($profile->visi); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="misi">Misi</label>
                            <textarea name="misi" id="misi" class="form-control"><?php echo e($profile->misi); ?></textarea>
                        </div>
                </div>
                <div class="card-footer">
                    <button class="btn btn-primary" type="submit">Update</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<!-- <?php endif; ?> -->
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pkl\resources\views/admin/profile/edit.blade.php ENDPATH**/ ?>