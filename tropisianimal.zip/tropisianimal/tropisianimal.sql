-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.7.24 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table tropisianimal.contacts
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lokasi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table tropisianimal.contacts: ~0 rows (approximately)
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` (`id`, `email`, `no`, `lokasi`, `created_at`, `updated_at`) VALUES
	(1, 'mufardiq25@gmail.com', '083877017617', 'Kab. Bogor', '2020-11-23 10:47:38', '2021-01-06 02:00:43');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;

-- Dumping structure for table tropisianimal.failed_jobs
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table tropisianimal.failed_jobs: ~0 rows (approximately)
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;

-- Dumping structure for table tropisianimal.galleries
CREATE TABLE IF NOT EXISTS `galleries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table tropisianimal.galleries: ~8 rows (approximately)
/*!40000 ALTER TABLE `galleries` DISABLE KEYS */;
INSERT INTO `galleries` (`id`, `foto`, `created_at`, `updated_at`) VALUES
	(3, '1606136236_alessandro-desantis-9_9hzZVjV8s-unsplash.png', '2020-11-23 10:32:55', '2020-11-23 12:57:16'),
	(5, '1606136248_david-clode-0lwa8Dprrzs-unsplash.png', '2020-11-23 12:57:28', '2020-11-23 12:57:28'),
	(6, '1606136268_david-clode-AtCChdVhAmA-unsplash.png', '2020-11-23 12:57:48', '2020-11-23 12:57:48'),
	(7, '1606136281_joshua-j-cotten-VCzNXhMoyBw-unsplash.png', '2020-11-23 12:58:01', '2020-11-23 12:58:01'),
	(8, '1606136294_kyaw-tun-_YIX48_4hgs-unsplash.png', '2020-11-23 12:58:14', '2020-11-23 12:58:14'),
	(11, '1606137455_smit-patel-dGMcpbzcq1I-unsplash.png', '2020-11-23 12:58:53', '2020-11-23 13:17:35'),
	(13, '1606470102_TERUMBU-KARANG (1).png', '2020-11-23 13:00:31', '2020-11-27 09:41:42'),
	(17, '1606470119_david-clode-0lwa8Dprrzs-unsplash.png', '2020-11-27 09:41:59', '2020-11-27 09:41:59');
/*!40000 ALTER TABLE `galleries` ENABLE KEYS */;

-- Dumping structure for table tropisianimal.messages
CREATE TABLE IF NOT EXISTS `messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table tropisianimal.messages: ~3 rows (approximately)
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` (`id`, `deskripsi`, `subject`, `email`, `nama`, `created_at`, `updated_at`) VALUES
	(4, 'asdf', 'coba coba', 'mufardiq25@gmail.com', 'fajar', '2021-01-06 08:35:45', '2021-01-06 08:35:45'),
	(5, 'ddd', 'p', 'muhammadfajarshodiq@smkwikrama.sch.id', 'njay', '2021-01-06 08:36:41', '2021-01-06 08:36:41'),
	(6, 'ping', 'masuk ga', 'nyoba@gmail.com', 'uji coba 2', '2021-01-09 03:40:29', '2021-01-09 03:40:29');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;

-- Dumping structure for table tropisianimal.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table tropisianimal.migrations: ~7 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(4, '2014_10_12_000000_create_users_table', 1),
	(5, '2014_10_12_100000_create_password_resets_table', 1),
	(6, '2019_08_19_000000_create_failed_jobs_table', 1),
	(7, '2020_11_23_042907_create_profiles_table', 1),
	(8, '2020_11_23_042935_create_news_table', 1),
	(9, '2020_11_23_043046_create_galleries_table', 1),
	(10, '2020_11_23_043110_create_contacts_table', 1),
	(11, '2021_01_06_072241_create_messages_table', 2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Dumping structure for table tropisianimal.news
CREATE TABLE IF NOT EXISTS `news` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `judul` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table tropisianimal.news: ~5 rows (approximately)
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` (`id`, `foto`, `judul`, `deskripsi`, `created_at`, `updated_at`) VALUES
	(21, '1608373519_rick-l-037fCBgZB10-unsplash.png', 'Apa kabar kebun binatang saat covid 19?', 'Lorem ipsum dolor sit amet consectetur adipisicing elit.', '2020-12-19 10:19:28', '2020-12-19 10:25:19'),
	(22, '1608373750_hans-veth-o33FMDaXJS8-unsplash.png', 'Anugrah dari hutan indonesia', 'Lorem ipsum dolor sit amet consectetur adipisicing elit.', '2020-12-19 10:29:10', '2020-12-19 10:29:10'),
	(23, '1608373843_ronald-gijezen-7h06P9UKhYY-unsplash.png', '10 hewan herbivora yang berbahaya', 'Lorem ipsum dolor sit amet consectetur adipisicing elit.', '2020-12-19 10:30:43', '2020-12-19 10:30:43'),
	(24, '1608374960_smit-patel-dGMcpbzcq1I-unsplash.png', '4 Penyakit yang ditularkan hewan ke manusia', 'Lorem ipsum dolor sit amet consectetur adipisicing elit.', '2020-12-19 10:49:20', '2020-12-19 10:49:20'),
	(25, '1608375054_TERUMBU-KARANG (1).png', 'Terumpu karang : pengertian, jenis, sebaran, dan masalah', 'Lorem ipsum dolor sit amet consectetur adipisicing elit.', '2020-12-19 10:50:54', '2020-12-19 10:50:54'),
	(26, '1608375207_vladimir-kudinov-vmlJcey6HEU-unsplash.png', 'Ternyata tanduk rusa berasal dari sel kanker tulang', 'Lorem ipsum dolor sit amet consectetur adipisicing elit.', '2020-12-19 10:53:27', '2020-12-19 10:53:27');
/*!40000 ALTER TABLE `news` ENABLE KEYS */;

-- Dumping structure for table tropisianimal.password_resets
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table tropisianimal.password_resets: ~0 rows (approximately)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
	('muhammadfajarshodiq@smkwikrama.sch.id', '$2y$10$UkwdUsPECPdIkR/lgBVyd..HMdlYy01/iyNzGycCtENVjHO6L9ZP2', '2021-01-06 04:10:21');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Dumping structure for table tropisianimal.profiles
CREATE TABLE IF NOT EXISTS `profiles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `p1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `p2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `visi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `misi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table tropisianimal.profiles: ~0 rows (approximately)
/*!40000 ALTER TABLE `profiles` DISABLE KEYS */;
INSERT INTO `profiles` (`id`, `p1`, `p2`, `visi`, `misi`, `created_at`, `updated_at`) VALUES
	(1, 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis libero quam hic aliquid in. Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis libero quam hic aliquid in', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis libero quam hic aliquid in doloribus tempore ducimus natus, reprehenderit deserunt! Voluptate placeat repellat minima, sed odit animi reiciendis id aliquam. Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis libero quam hic aliquid in doloribus tempore ducimus natus, reprehenderit deserunt!', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis libero quam hic aliquid in doloribus tempore ducimus natus, reprehenderit deserunt! Voluptate placeat repellat minima, sed odit animi reiciendis id aliquam.', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis libero quam hic aliquid in doloribus tempore ducimus natus, reprehenderit deserunt! Voluptate placeat repellat minima, sed odit animi reiciendis id aliquam.', '2020-11-23 08:00:34', '2020-11-24 07:29:20');
/*!40000 ALTER TABLE `profiles` ENABLE KEYS */;

-- Dumping structure for table tropisianimal.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table tropisianimal.users: ~0 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, 'admin', 'admin@admin.com', NULL, '$2y$10$Jeg2PgJundXjwgYNpNjQu.xxy3U3vpGwiNMydmJr4ZlkA8zQ7E/l.', NULL, '2020-11-23 11:35:54', '2020-11-23 11:35:54'),
	(2, 'muhammad fajar shodiq', 'muhammadfajarshodiq@smkwikrama.sch.id', NULL, '$2y$10$MObuYlkODLszaQTxWQZwTuzBAohE/yxC.cf1w5Oz9.S26qPFLPldO', NULL, '2021-01-06 04:05:14', '2021-01-06 04:05:14');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
